<!--/* Start_Top_Title_bar */  -->                                                       
       <table class="table-header" align="center">
        <tr>
          <td align="left" class="home" width="25%"> <a href="../index.php" id="home" target="_self">خانه</a></td>
          <td align="center" class="title" width="50%">مدیریت ویب سایت</td>
          <td align="right" class="flash" width="25%"> <a href="../blog.php" id="flash" target="_self">ویبلاگ</a></td>
        </tr>
      </table>
 <!--/* End_Top_Title_bar */-->