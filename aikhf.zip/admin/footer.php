
<style>
/*<!--Footer-->*/
#footer{ background-color:#10379e; border-top:5px solid rgba(0,0,0,0.1); position:relative;}

#footer_tab{ color:#FFFFFF; font-family:Tahoma; 
			 font-size: small; line-height:20px;
			 } 
a { text-decoration:none;} 
#footer_tab a{text-decoration:none; color:#CCC;}
#footer_tab a:hover{ color:#FFF;}
/*<!--Footer-->*/
</style>
 <!--Start_footer_End-->
  <div align="center" id="footer" dir="rtl">
    <table id="footer_tab" width="1026" height="90" class="footer_tab">
      <tr>
         <td align="center" width="500">
         <p>تمامی حقوق مطالب این سایت محفوظ بوده و متعلق به حسینیه پیروان اهل بیت محمد مصطفی (ص) AIKHF می باشد. (<?php echo $datetime=date("Y"); //date time ?>)
      <br>کپی برداری از محتوای سایت با نشان <a href="index.php" title="template">حسینیه پیروان اهل بیت محمد مصطفی (ص) AIKHF</a> مجاز می باشد. 
      <br>طرح و گسترش: ذبیح الله خالقی
    </p>
         </td>
      </tr>
    </table>
  </div> 
 <!--End_footer_End-->