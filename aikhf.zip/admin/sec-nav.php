 <!--Start_Admin/Clease/Teacher/Students-->
            <table  width="1015" height="40" cellpadding="0" cellspacing="0" class="nav-bar">
              <tr align="center">
                  <td width="150" id="nav"> <a href="admin.php"  class="admin">مدیریت</a></td>
                  <td width="5">&nbsp;</td>
                  <td width="150" id="nav"> <a href="inbox.php" class="inbox">پیامها</a></td>
                  <td width="5">&nbsp;</td>
                  
                  <td width="150" id="nav"> <a href="about_add.php" class="image">درباره ما</a></td>
                  <td width="5">&nbsp;</td>
                  <td width="150" id="nav"> <a href="video_add.php" class="upload">ویدیو</a></td>
                  <td width="5">&nbsp;</td>
                  <td width="150" id="nav"> <a href="slide.php" class="slide">گالری عکس</a></td>
                  <td width="5">&nbsp;</td>
                  <td width="150" id="nav"> <a href="blog_add.php" class="picture">خبرها</a></td>
                  <td width="5">&nbsp;</td>
                  <td width="150" id="nav"> <a href="member_add.php" class="upload">اعضا</a></td>
                  <td width="5">&nbsp;</td>
                  <td width="150" id="nav"> <a href="links_add.php" class="top-10">لینکها</a></td>
              </tr>
         </table>
      <!--End_Admin/Clease/Teacher/Students-->