<?php 
$con = mysql_connect('localhost','root','');
mysql_select_db('nahoorvoice',$con);
if(!isset($con)) {
	die("Connection to database failed." .mysql_error());	
}

?>