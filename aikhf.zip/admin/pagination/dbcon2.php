<?php
 // database connection details
        $MySQL_host     = 'localhost';
        $MySQL_username = 'root';
        $MySQL_password = '';
        $MySQL_database = 'nahoorvoice';
		?>